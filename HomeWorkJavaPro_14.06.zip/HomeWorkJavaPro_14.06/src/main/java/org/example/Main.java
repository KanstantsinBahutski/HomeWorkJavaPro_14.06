package org.example;

import static org.example.Phone.*;

public class Main {
    public static void main(String[] args) {
        // #1
        Person alex = new Person();
        alex.setFullName("Alex Vorona");
        alex.move();
        alex.talk();
        Person oleg = new Person("Oleg Bereza", 17);
        oleg.move();
        oleg.talk();

        // #2
        Phone phone1 = new Phone("513263228", "X", 0.453);
        Phone phone2 = new Phone("513264228", "Y", 0.473);
        Phone phone3 = new Phone("513265228", "Z", 0.423);
        System.out.println("Phone 1:");
        System.out.println("Номер " + phone1.getNumber());
        System.out.println("Модель " + phone1.getModel());
        System.out.println("Вес " + phone1.getWeight());

        System.out.println("\nPhone 2:");
        System.out.println("Номер " + phone2.getNumber());
        System.out.println("Модель " + phone2.getModel());
        System.out.println("Вес " + phone2.getWeight());

        System.out.println("\nPhone 3:");
        System.out.println("Номер " + phone3.getNumber());
        System.out.println("Модель " + phone3.getModel());
        System.out.println("Вес " + phone3.getWeight());

        phone1.receiveCall("Витя");
        phone2.receiveCall("Гена");
        phone3.receiveCall("Жора");

    }
}