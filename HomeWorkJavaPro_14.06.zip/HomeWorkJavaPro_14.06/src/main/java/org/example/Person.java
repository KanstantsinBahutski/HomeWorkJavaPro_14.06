package org.example;

public class Person {
    public static String fullName;
    public static int age;


    public Person() {
    }

    public Person(String fullName, int age){
        this.fullName = fullName;
        this.age = age;
    }

    public static String getFullName() {
        return fullName;
    }

    public static void setFullName(String fullName) {
        Person.fullName = fullName;
    }

    public static int getAge() {
        return age;
    }

    public static void setAge(int age) {
        Person.age = age;
    }

    public static void move(){
        System.out.println("Person " + Person.fullName + " идет");
    }

    public static void talk(){
        System.out.println("Person " + Person.fullName + " говорит");
    }


}

